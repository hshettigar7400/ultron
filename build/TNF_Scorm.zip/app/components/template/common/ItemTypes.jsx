export default {
  STAR: 'star',
};
