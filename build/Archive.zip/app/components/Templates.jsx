import React from 'react';
import StaticPage1 from './template/StaticPage1';
import StaticPage2 from './template/StaticPage2';
import StaticPage3 from './template/StaticPage3';
import StaticPage4 from './template/StaticPage4';
import StaticPage5 from './template/StaticPage5';

export {
  StaticPage1,
  StaticPage2,
  StaticPage3,
  StaticPage4,
  StaticPage5
}
