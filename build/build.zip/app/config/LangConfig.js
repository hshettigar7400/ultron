const LangConfig = [
  {value: 'en', label: 'English'},
  {value: 'es', label: 'Spanish'},
  {value: 'fr', label: 'French'},
  {value: 'in', label: 'Indonesian'},
  {value: 'pl', label: 'Polish'},
  {value: 'pt', label: 'Portuguese'},
  {value: 'ru', label: 'Russian'},
  {value: 'vi', label: 'Vietnamese'},
  {value: 'zh', label: 'Chinese'}
]

module.exports = {
  LangConfig
}
