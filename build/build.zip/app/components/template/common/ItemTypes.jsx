export default {
  CAUSEEXAMS: 'Conflict of Interest',
  SWEEPEXAMS: 'Media policy'
};
